from RSA import RSA

rsa = RSA()
rsa.encrypt_image(r'./RSA_origin.png', r'./RSA_encode.png')
